package Task;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.Date;

public class Task implements Parcelable {
    public static final Creator<Task> CREATOR = new Creator<Task>() {
        @Override
        public Task createFromParcel(Parcel in) {
            return new Task(in);
        }

        @Override
        public Task[] newArray(int size) {
            return new Task[size];
        }
    };
    private final String description;

    public Task(String description, Date dateTime) {
        this.description = description;
    }

    // Parcelable implementation
    protected Task(Parcel in) {
        description = in.readString();
    }

    public String getDescription() {
        return description;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(description);
    }

    @Override
    public int describeContents() {
        return 0;
    }
}
